package ejercicio4;

public class FraccionException extends Exception{
	public FraccionException(String cadena) {
		super(cadena);
	}
}
