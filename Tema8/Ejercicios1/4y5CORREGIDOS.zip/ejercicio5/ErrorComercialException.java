package ejercicio5;

public class ErrorComercialException extends Exception{
	public ErrorComercialException(String msg) {
		super(msg);
	}
}
